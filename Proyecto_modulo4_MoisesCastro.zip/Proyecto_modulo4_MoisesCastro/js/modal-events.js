$(document).ready(function() {
  var modal = $('#exampleModal');
  var button = $('#openModalBtn');

  modal.on('show.bs.modal', function () {
    console.log('Modal comenzando a abrirse');
    button.prop('disabled', true).removeClass('btn-primary').addClass('btn-warning');
  });

  modal.on('shown.bs.modal', function () {
    console.log('Modal totalmente abierto');
  });

  modal.on('hide.bs.modal', function () {
    console.log('Modal empezando a cerrarse');
  });

  modal.on('hidden.bs.modal', function () {
    console.log('Modal completamente cerrado');
    button.prop('disabled', false).removeClass('btn-warning').addClass('btn-primary');
  });
});
