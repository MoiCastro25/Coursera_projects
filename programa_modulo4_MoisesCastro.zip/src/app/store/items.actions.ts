import { createAction, props } from '@ngrx/store';

export const addItem = createAction(
  '[Items] Add',
  props<{ item: any }>()
);

export const loadItems = createAction(
  '[Items] Load',
  props<{ items: any[] }>()
);
