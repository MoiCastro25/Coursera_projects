import { createReducer, on } from '@ngrx/store';
import { addItem, loadItems } from './items.actions';

export interface ItemsState {
  items: any[];
}

export const initialState: ItemsState = {
  items: []
};

export const itemsReducer = createReducer(
  initialState,
  on(loadItems, (s, { items }) => ({ ...s, items })),
  on(addItem, (s, { item }) => ({ ...s, items: [...s.items, item] }))
);
