import { Directive } from '@angular/core';

@Directive({
  selector: '[appTrackClick]',
})
export class TrackClick {

  constructor() { }

}
