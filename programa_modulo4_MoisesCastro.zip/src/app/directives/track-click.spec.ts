import { TrackClick } from './track-click';

describe('TrackClick', () => {
  it('should create an instance', () => {
    const directive = new TrackClick();
    expect(directive).toBeTruthy();
  });
});
