import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { itemsReducer } from './store/items.reducer';

import { APP_CONFIG } from './config/app.tokens';
import { ApiDataService } from './services/api-data.service';
import { BaseService } from './services/base.service';
import { DerivedService } from './services/derived.service';

import { LoginComponent } from './components/login/login.component';
import { ProtectedComponent } from './components/protected/protected.component';
import { ItemsListComponent } from './components/items-list/items-list.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProtectedComponent,
    ItemsListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot({ itemsState: itemsReducer })
  ],
  providers: [
    // InjectionToken config
    { provide: APP_CONFIG, useValue: { apiUrl: 'http://localhost:3000/api' } },

    // useClass
    { provide: 'IDataService', useClass: ApiDataService },

    // useExisting
    DerivedService,
    { provide: BaseService, useExisting: DerivedService }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
