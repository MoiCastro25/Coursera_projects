import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { addItem, loadItems } from '../store/items.actions';
import { APP_CONFIG } from '../config/app.tokens';
import { DexieService } from './dexie.service';

@Injectable({ providedIn: 'root' })
export class ItemsService {

  constructor(
    private http: HttpClient,
    private store: Store,
    private db: DexieService,
    @Inject(APP_CONFIG) private config: any
  ) {}

  // Obtener lista
  load() {
    this.http.get<any[]>(`${this.config.apiUrl}/items`)
      .subscribe(items => {
        this.store.dispatch(loadItems({ items }));
      });
  }

  // Agregar item
  add(name: string) {
    this.http.post<any>(`${this.config.apiUrl}/items`, { name })
      .subscribe(resp => {
        if (resp.ok) {
          this.store.dispatch(addItem({ item: resp.item }));
          this.db.addItem(resp.item); // guardar en Dexie
        }
      });
  }
}
