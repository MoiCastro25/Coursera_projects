import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private logged = new BehaviorSubject<boolean>(false);
  isLogged$ = this.logged.asObservable();

  login() { this.logged.next(true); }
  logout() { this.logged.next(false); }
  isLogged() { return this.logged.value; }
}
