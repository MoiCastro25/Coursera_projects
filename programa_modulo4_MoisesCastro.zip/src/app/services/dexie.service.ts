import { Injectable } from '@angular/core';
import Dexie from 'dexie';

export interface Item {
  id?: number;
  name: string;
}

@Injectable({ providedIn: 'root' })
export class DexieService extends Dexie {
  items!: Dexie.Table<Item, number>;

  constructor() {
    super("AppDB");

    this.version(1).stores({
      items: '++id,name'
    });

    this.items = this.table('items');
  }

  addItem(item: Item) {
    return this.items.add(item);
  }
}
