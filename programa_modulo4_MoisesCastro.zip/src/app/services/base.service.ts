export class BaseService {
  getName() { return "BaseService"; }
}
