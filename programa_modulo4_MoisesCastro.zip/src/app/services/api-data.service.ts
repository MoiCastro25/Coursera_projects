import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { APP_CONFIG } from '../config/app.tokens';

@Injectable()
export class ApiDataService {

  constructor(
    private http: HttpClient,
    @Inject(APP_CONFIG) private config: any
  ) {}

  getItems() {
    return this.http.get(`${this.config.apiUrl}/items`);
  }
}
