import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { ItemsService } from '../../services/items.service';

@Component({
  selector: 'app-items-list',
  templateUrl: './items-list.component.html'
})
export class ItemsListComponent implements OnInit {

  items$ = this.store.select(s => s.itemsState.items);

  constructor(private items: ItemsService, private store: Store) {}

  ngOnInit() {
    this.items.load();
  }

  add(txt: HTMLInputElement) {
    this.items.add(txt.value);
    txt.value = "";
  }
}
