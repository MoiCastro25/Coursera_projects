import { Component } from '@angular/core';

@Component({
  selector: 'app-animated',
  imports: [],
  templateUrl: './animated.html',
  styleUrl: './animated.css',
})
export class Animated {

}
