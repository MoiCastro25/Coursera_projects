const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let items = [
  { id: 1, name: "Item inicial" }
];
let nextId = 2;

app.get('/api/items', (req, res) => {
  res.json(items);
});

app.post('/api/items', (req, res) => {
  const item = req.body;
  if (!item.name) return res.status(400).json({ ok: false });

  item.id = nextId++;
  items.push(item);

  res.json({ ok: true, item });
});

app.listen(3000, () => console.log("API corriendo en puerto 3000"));
