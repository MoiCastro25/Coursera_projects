import { Routes } from '@angular/router';
import { ListaDestinosComponent } from './lista-destinos/lista-destinos';
import { PadreComponent } from './padre/padre.component';

export const routes: Routes = [
  { path: 'lista', component: ListaDestinosComponent },
  { path: 'padre', component: PadreComponent },
  { path: '', redirectTo: 'lista', pathMatch: 'full' }
];
