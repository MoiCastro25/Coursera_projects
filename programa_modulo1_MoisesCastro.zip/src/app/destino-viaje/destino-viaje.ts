import { Component, Input, HostBinding } from '@angular/core';
import { DestinoViaje } from '../models/destino-viaje.model';

@Component({
  selector: 'app-destino-viaje',
  standalone: true,
  templateUrl: './destino-viaje.html',
  styleUrls: ['./destino-viaje.css']
})
export class DestinoViajeComponent {
  @Input() destino!: DestinoViaje;

  // @HostBinding para añadir clases bootstrap a la etiqueta host
  @HostBinding('class') cssClass = 'col-md-4';
}
