import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-hijo',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <input [(ngModel)]="mensaje" placeholder="Escribe algo">
    <button (click)="enviar()">Enviar al padre</button>
  `
})
export class HijoComponent {
  mensaje: string = '';
  @Output() mensajeEnviado = new EventEmitter<string>();

  enviar() {
    this.mensajeEnviado.emit(this.mensaje);
    this.mensaje = '';
  }
}
