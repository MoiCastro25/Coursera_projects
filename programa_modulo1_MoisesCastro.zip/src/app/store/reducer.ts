import { createReducer, on } from '@ngrx/store';
import { Item } from '../models/item.model';
import { VotoPositivo, VotoNegativo, BorrarItem } from './actions';

export const initialState: Item[] = [];

export const itemsReducer = createReducer(
  initialState,
  on(VotoPositivo, (state, { id }) =>
    state.map(item =>
      item.id === id ? { ...item, votosPositivos: item.votosPositivos + 1 } : item
    )
  ),
  on(VotoNegativo, (state, { id }) =>
    state.map(item =>
      item.id === id ? { ...item, votosNegativos: item.votosNegativos + 1 } : item
    )
  ),
  on(BorrarItem, (state, { id }) => state.filter(item => item.id !== id))
);
