import { Item } from '../models/item.model';

export interface AppState {
  items: Item[];
}
