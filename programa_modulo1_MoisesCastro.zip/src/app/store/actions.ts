import { createAction, props } from '@ngrx/store';

export const VotoPositivo = createAction('[Item] Voto Positivo', props<{ id: number }>());
export const VotoNegativo = createAction('[Item] Voto Negativo', props<{ id: number }>());
export const BorrarItem = createAction('[Item] Borrar', props<{ id: number }>());
