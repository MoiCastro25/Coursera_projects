export class DestinoViaje {
  constructor(
    public nombre: string,
    public imagenUrl: string
  ) {}
}
