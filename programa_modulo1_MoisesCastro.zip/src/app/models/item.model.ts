export interface Item {
  id: number;
  nombre: string;
  url: string;
  votosPositivos: number;
  votosNegativos: number;
}
