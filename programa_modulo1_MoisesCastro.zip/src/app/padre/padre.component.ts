import { Component } from '@angular/core';

@Component({
  selector: 'app-padre',
  standalone: true,
  templateUrl: './padre.component.html',
  styleUrls: ['./padre.component.css']
})
export class PadreComponent {

  nombre: string = '';

  actualizarNombre(nuevoNombre: string) {
    this.nombre = nuevoNombre;
    console.log("Nuevo nombre:", this.nombre);
  }

}
