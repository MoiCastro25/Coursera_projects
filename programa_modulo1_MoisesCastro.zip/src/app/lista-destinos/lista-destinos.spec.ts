import { Component } from '@angular/core';
import { DestinoViajeComponent } from '../destino-viaje/destino-viaje';
import { DestinoViaje } from '../models/destino-viaje.model';

@Component({
  selector: 'app-lista-destinos',
  standalone: true,
  imports: [DestinoViajeComponent],
  templateUrl: './lista-destinos.html',
  styleUrls: ['./lista-destinos.css']
})
export class ListaDestinosComponent {
  destinos: DestinoViaje[] = [];

  Guardar(nombreInput: HTMLInputElement, urlInput: HTMLInputElement): boolean {
    const nuevoDestino = new DestinoViaje(nombreInput.value, urlInput.value);
    this.destinos.push(nuevoDestino);

    nombreInput.value = '';
    urlInput.value = '';
    return false; // evita recargar la página
  }
}
