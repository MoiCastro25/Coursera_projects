import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DestinoViajeComponent } from '../destino-viaje/destino-viaje';
import { DestinoViaje } from '../models/destino-viaje.model';

@Component({
  selector: 'app-lista-destinos',
  standalone: true,
  imports: [CommonModule, FormsModule, DestinoViajeComponent],
  templateUrl: './lista-destinos.html',
  styleUrls: ['./lista-destinos.css']
})
export class ListaDestinosComponent {
  destinos: DestinoViaje[] = [];

  Guardar(nombreInput: HTMLInputElement, urlInput: HTMLInputElement): boolean {
    if (!nombreInput.value.trim() || !urlInput.value.trim()) {
      alert('Debe completar ambos campos');
      return false;
    }

    const nuevoDestino = new DestinoViaje(nombreInput.value, urlInput.value);
    this.destinos.push(nuevoDestino);

    nombreInput.value = '';
    urlInput.value = '';

    return false;
  }
}
