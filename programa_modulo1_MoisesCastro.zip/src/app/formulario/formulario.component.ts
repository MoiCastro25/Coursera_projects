import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-formulario',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './formulario.component.html'
})
export class FormularioComponent {
  @Output() enviarNombre = new EventEmitter<string>();

  miFormulario: FormGroup;

  constructor(private fb: FormBuilder) {
    this.miFormulario = this.fb.group({
      nombre: ['', Validators.required],
      edad: ['', [Validators.required, this.validarEdadMinima(18)]]
    });
  }

  enviar() {
    if (this.miFormulario.valid) {
      this.enviarNombre.emit(this.miFormulario.value.nombre);
      this.miFormulario.reset();
    }
  }

  validarEdadMinima(min: number) {
    return (control: any) => {
      const valor = control.value;
      return valor >= min ? null : { edadMinima: { requiredAge: min } };
    };
  }

  hasError(controlName: string, errorName: string) {
    return this.miFormulario.get(controlName)?.errors?.[errorName] && this.miFormulario.get(controlName)?.touched;
  }
}
