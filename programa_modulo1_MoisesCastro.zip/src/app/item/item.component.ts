import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Item } from '../models/item.model';


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html'
})
export class ItemComponent {
  @Input() item!: Item;
  @Output() emitirVoto = new EventEmitter<{ id: number, tipo: 'positivo' | 'negativo' }>();
  @Output() emitirBorrar = new EventEmitter<number>();

  votoPositivo() {
    this.emitirVoto.emit({ id: this.item.id, tipo: 'positivo' });
  }

  votoNegativo() {
    this.emitirVoto.emit({ id: this.item.id, tipo: 'negativo' });
  }

  borrar() {
    this.emitirBorrar.emit(this.item.id);
  }
}
